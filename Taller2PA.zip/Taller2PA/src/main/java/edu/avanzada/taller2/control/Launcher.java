
package edu.avanzada.taller2.control;

import java.io.IOException;

public class Launcher {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        new ControlPrincipal();
    }
    
}
